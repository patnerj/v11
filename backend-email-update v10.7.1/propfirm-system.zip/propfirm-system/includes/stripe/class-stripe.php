<?php
/**
 * FXSIM_Stripe — Stripe Checkout integration
 * Uses Stripe Checkout Sessions (no card data on our server)
 * Flow: create session → redirect to Stripe → webhook confirms → challenge created
 */
defined('ABSPATH') || exit;

class FXSIM_Stripe {

    // ── Create a Stripe Checkout session ─────────────────────────────────────
    public static function create_checkout(int $user_id, int $plan_id, string $coupon_code = ''): array {
        $sk = FXSIM_Challenge_DB::get_setting('stripe_secret_key', '');
        if (!$sk) return ['success' => false, 'message' => 'Stripe not configured. Please use manual payment.'];

        $plan = FXSIM_Challenge_DB::get_plan($plan_id);
        if (!$plan) return ['success' => false, 'message' => 'Plan not found.'];

        if ((float)$plan->price <= 0) return ['success' => false, 'message' => 'This plan is free — no Stripe needed.'];

        // Compute the post-discount total WITHOUT creating an order. The order is
        // created + activated only when Stripe confirms payment (webhook), so a
        // cancelled checkout leaves no pending order, no admin notification, and
        // no admin email. Coupon validation here is read-only (no redemption).
        $price = (float)$plan->price; $discount = 0.0; $code_stored = '';
        if (class_exists('FXSIM_Coupons') && trim($coupon_code) !== '') {
            $v = FXSIM_Coupons::validate($coupon_code, $plan_id, $user_id);
            if (!empty($v['valid'])) { $discount = (float)$v['discount']; $code_stored = (string)$v['code']; }
        }
        $pay    = max(0, round($price - $discount, 2));
        $amount = (int)round($pay * 100); // Stripe uses cents
        if ($amount < 50) {
            // Below Stripe's minimum charge (e.g. a near/100% discount).
            return ['success' => false, 'message' => 'This order total is too low for card checkout — please use manual payment.'];
        }

        $user     = get_userdata($user_id);
        $brand    = FXSIM_Challenge_DB::get_setting('brand_name', 'PropFirm System');
        $currency = strtolower($plan->currency ?? 'usd');

        // Stripe API call
        $fe = get_option('fxsim_frontend_url', '');
        if (!$fe && defined('FXSIM_FRONTEND_URL')) $fe = FXSIM_FRONTEND_URL;
        $fe = $fe ? untrailingslashit($fe) : untrailingslashit(home_url());

        $response = wp_remote_post('https://api.stripe.com/v1/checkout/sessions', [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Bearer ' . $sk,
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body' => http_build_query([
                'payment_method_types[0]'           => 'card',
                'line_items[0][price_data][currency]'            => $currency,
                'line_items[0][price_data][product_data][name]'  => $brand . ' — ' . $plan->name,
                'line_items[0][price_data][product_data][description]' => 'Challenge account: $' . number_format((float)$plan->account_size) . ' | ' . $plan->p1_profit_target . '% target | ' . $plan->funded_profit_split . '% profit split',
                'line_items[0][price_data][unit_amount]'         => $amount,
                'line_items[0][quantity]'                        => 1,
                'mode'                              => 'payment',
                'customer_email'                    => $user->user_email ?? '',
                'success_url'                       => $fe . '/dashboard?stripe=success',
                'cancel_url'                        => $fe . '/challenges?stripe=cancelled',
                'metadata[user_id]'                 => $user_id,
                'metadata[plan_id]'                 => $plan_id,
                'metadata[coupon_code]'             => $code_stored,
            ]),
        ]);

        if (is_wp_error($response)) {
            return ['success' => false, 'message' => 'Stripe connection failed: ' . $response->get_error_message()];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!empty($body['error'])) {
            return ['success' => false, 'message' => 'Stripe error: ' . ($body['error']['message'] ?? 'Unknown')];
        }

        if (empty($body['url'])) {
            return ['success' => false, 'message' => 'Stripe did not return a checkout URL.'];
        }

        return [
            'success'      => true,
            'checkout_url' => $body['url'],
            'session_id'   => $body['id'],
        ];
    }

    // ── Handle Stripe Webhook ─────────────────────────────────────────────────
    public static function handle_webhook(): void {
        $wh_secret = FXSIM_Challenge_DB::get_setting('stripe_webhook_secret', '');
        $payload   = file_get_contents('php://input');
        $sig       = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

        // Verify signature if webhook secret is set
        if ($wh_secret && $sig) {
            if (!self::verify_signature($payload, $sig, $wh_secret)) {
                http_response_code(400);
                echo json_encode(['error' => 'Invalid signature']);
                exit;
            }
        }

        $event = json_decode($payload, true);
        if (!$event || !isset($event['type'])) {
            http_response_code(400); exit;
        }

        if ($event['type'] === 'checkout.session.completed') {
            global $wpdb;
            $session    = $event['data']['object'];
            $user_id    = (int)($session['metadata']['user_id'] ?? 0);
            $plan_id    = (int)($session['metadata']['plan_id'] ?? 0);
            $coupon     = (string)($session['metadata']['coupon_code'] ?? '');
            $session_id = (string)($session['id'] ?? '');
            $paid       = ($session['payment_status'] ?? '') === 'paid' || ($session['status'] ?? '') === 'complete';

            if ($user_id && $plan_id && $paid) {
                // Idempotency: if this session was already processed, do nothing.
                $already = $session_id ? $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}fxsim_payment_orders WHERE txn_id=%s", $session_id)) : 0;
                if (!$already) {
                    // Create the order only now (payment confirmed), then auto-activate.
                    $res = FXSIM_Payments::create_order($user_id, $plan_id, 'stripe', $coupon);
                    $oid = (int)($res['order_id'] ?? 0);
                    if ($oid) {
                        if ($session_id) $wpdb->update($wpdb->prefix . 'fxsim_payment_orders', ['txn_id' => $session_id], ['id' => $oid]);
                        FXSIM_Payments::approve_order($oid, 0, 'Auto-approved via Stripe');
                    }
                }
            }
        }

        http_response_code(200);
        echo json_encode(['received' => true]);
        exit;
    }

    // ── Verify Stripe webhook signature ──────────────────────────────────────
    private static function verify_signature(string $payload, string $sig_header, string $secret): bool {
        $parts     = explode(',', $sig_header);
        $timestamp = '';
        $signatures = [];

        foreach ($parts as $part) {
            [$key, $value] = explode('=', $part, 2);
            if ($key === 't') $timestamp = $value;
            if ($key === 'v1') $signatures[] = $value;
        }

        if (!$timestamp) return false;

        $signed_payload = $timestamp . '.' . $payload;
        $expected       = hash_hmac('sha256', $signed_payload, $secret);

        foreach ($signatures as $sig) {
            if (hash_equals($expected, $sig)) return true;
        }
        return false;
    }
}
